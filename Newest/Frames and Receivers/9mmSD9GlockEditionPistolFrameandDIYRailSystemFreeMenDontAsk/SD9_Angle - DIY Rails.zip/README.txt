SD9_Angle

Intro:
This is an easily adaptable method for making pistol rails, using angle aluminum found in any hardware store. This front rail is tested and verified to work with the SD9. It will presumably work with the SD40, SW9 and SW40, as long as a rear rail solution has been acquired for the SW series, but this is currently unconfirmed. For this version for the SD9, I used 1" wide 1/16" thick angle aluminum. It is commonly available in 8 foot long sticks for ~$12. This represents possibly the cheapest possible way of making these rails where the bearing surface is aluminum. This was inspired by a Canadian FOSSCADer who came up with the idea.

I added about 1mm of thickness to the internal surface of the printed rail module, when compared to the original front rail blocks, to better support the aluminum sections in place. This doesn't interfere with the recoil spring.

The dimensions on these rails don't have to be exact, but use your best judgement.

Materials:
	1/16" Angle aluminum, with one of the legs at least 1" long. 1"x1" works well. Ex:
		https://www.homedepot.com/p/Everbilt-1-in-x-96-in-Aluminum-Angle-with-1-16-in-Thick-800057/204325583
	Epoxy
	1 roll pin. I just used one that fit from a Harbor Freight roll pin set. Ex:
		https://www.harborfreight.com/120-piece-roll-pin-storehouse-67591.html
	Printer filament

Tools:
	Hacksaw/Jigsaw/Bandsaw
	Calipers
	3D Printer
	File
	Sandpaper

Dimensions:
       >||
      . ||
      . ||
19.75mm ||
      . ||
      . ||
       >L====
        ^4mm^

	This profile should be 19.875mm long.



How To:
	1. Decide what aluminum stock you're going to use and go buy it.
	2. Print the central module. PLA should work fine. I printed mine solid.
	3. Use your calipers to score your measurements into the aluminum. These measurements will change for each pistol module, but for the SD9, the short leg will be 4 mm long, the long leg will be 19.75mm long, and the width will be 19.875mm long. 
	4. Cut the aluminum sideplates to size. A bandsaw would be idea, but a jigsaw or a hacksaw will do in a pinch, then use a file to get closer the final dimensions. Err on making the dimensions oversized, then use the printed module as a template, and file the aluminum edges flush with their printed counterparts.
	5. Index the newly cut sideplates so that their rail tops are flush with the top of the printed center module. Use the printed center module as a template for drilling the roll pin hole in each of the sideplates.
	6. Epoxy the aluminum sideplates to the printed center module, again indexing the sideplates so that they are flush with the top surfaces of the rail module. Let sit for a few minutes so the epoxy can harden.
	7. Grind/file/sand the short legs of the completed rail module down to size so the slide glides cleanly over it. 
	8. Pin and/or epoxy the the rail module in place in the frame.